# Trust Core final-result evidence bundle

This bundle preserves the selected primary receipts and the two reconstruction inputs for the completed Trust Core campaign reviewed under ledger thread T311.

## Authoritative scientific result

- Promoted start: tree `7905346e6cbba116bb60856fc3e5b62de0a74b0090ba088a2fff73c8868c33a9`; vector 83 verification / 8 resource-limit / 92 raw errors / 1,527 verified checks.
- Accepted terminal: tree `978872a3850e74067068e8f3ff7375266740b83da37f1f8eaf6ca0cb2ef009c3`; vector 0 verification / 0 resource-limit / 0 raw errors / 1,826 verified checks.
- Terminal integrity: zero hard admits, 27 intentional axioms, and empty forbidden-construct, frozen-definition, new-axiom, tooling-drift, and specification-drift sets.
- Reproducibility: four reviewed green executions. The fourth reconstructed the exact 726-file terminal tree from baseline commit `4caeec90e06e53f1ca6b14980f64745caaf85868`, `reconstruction/cumulative.patch`, and `reconstruction/Cargo.lock` before verification.

## Accounting boundary

The recorded terminal-run cost is `$36.9268345`, and the visible recorded campaign sum is `$1166.7791045`. Both are lower bounds, not exact cost certificates: at least three upstream responses lack receipts. The mechanical `complete` labels in `receipts/usage_audit.json` and `receipts/terminal_validation.json` cover only the receipted subset and are non-authoritative for an exact campaign-total claim.

## Verify the bundle

Run:

```sh
./verify_checksums.sh
```

## Reconstruct and re-run

Starting in a clone of the source repository that contains the pinned baseline:

```sh
git checkout --detach 4caeec90e06e53f1ca6b14980f64745caaf85868
git apply --check /path/to/reconstruction/cumulative.patch
git apply /path/to/reconstruction/cumulative.patch
cp /path/to/reconstruction/Cargo.lock ./Cargo.lock
```

The resulting canonical 726-file source receipt must equal terminal tree `978872a3850e74067068e8f3ff7375266740b83da37f1f8eaf6ca0cb2ef009c3` before scientific credit. In verifier image ID `sha256:062b832a08f9740d9865593d82240c5deb2c64fb8a78ab80f956dcba2272fed2`, mount that source tree read-only at `/work`, disable networking, provide a fresh writable Cargo target directory, and run:

```sh
/usr/bin/python3 /opt/harness/skills/verus_check.py \
  /work/curve25519-dalek/src/ristretto.rs \
  --project /work/curve25519-dalek \
  --whole-crate --timeout 900 --rlimit 80.0
```

The expected parsed outcome is return code 0, nontruncated output, 1,826 verified checks, and zero verification, resource-limit, and raw Verus errors.

## Layout

- `receipts/`: runner, round, terminal-gate, promotion, validation, and usage records.
- `audit/`: the third and fourth post-closure green replay records.
- `reconstruction/`: the cumulative binary patch and separately sealed ignored `Cargo.lock`.
- `supervisor/`: terminal state and append-only supervisor ledger.
- `paper/trust_core_final.json`: machine-readable paper fact record.

